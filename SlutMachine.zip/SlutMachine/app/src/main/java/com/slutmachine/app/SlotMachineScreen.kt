package com.slutmachine.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import com.slutmachine.app.ui.theme.*

@Composable
fun SlotMachineScreen(viewModel: SlotMachineViewModel = viewModel()) {

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(DarkBg, DeepPurple, DarkBg)
                    )
                )
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                text = "SLUT MACHINE",
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                color = HotPink,
                modifier = Modifier.padding(top = 20.dp, bottom = 4.dp)
            )

            Text(
                text = "18+ · Только для взрослых",
                fontSize = 13.sp,
                color = SoftPink.copy(alpha = 0.85f)
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Баланс
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Твои монеты", color = Color.Gray, fontSize = 12.sp)
                        Text(
                            text = "${viewModel.coins}",
                            color = Gold,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (viewModel.lastWin > 0) {
                        Text(
                            text = "+${viewModel.lastWin}",
                            color = Color(0xFF00FF88),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Button(
                        onClick = { viewModel.openPaywall() },
                        colors = ButtonDefaults.buttonColors(containerColor = HotPink),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text("Пополнить", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Барабаны
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Black),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(3.dp, HotPink, RoundedCornerShape(20.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 22.dp, horizontal = 6.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    viewModel.reels.forEach { symbol ->
                        ReelBox(symbol = symbol)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = viewModel.message,
                color = SoftPink,
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 12.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Ставка
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Button(
                    onClick = { viewModel.decreaseBet() },
                    enabled = !viewModel.isSpinning,
                    colors = ButtonDefaults.buttonColors(containerColor = CardBg),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("-", fontSize = 22.sp, color = HotPink)
                }

                Text(
                    text = "Ставка: ${viewModel.bet}",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )

                Button(
                    onClick = { viewModel.increaseBet() },
                    enabled = !viewModel.isSpinning,
                    colors = ButtonDefaults.buttonColors(containerColor = CardBg),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("+", fontSize = 22.sp, color = HotPink)
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Кнопка спина
            Button(
                onClick = { viewModel.spin() },
                enabled = !viewModel.isSpinning,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = HotPink,
                    disabledContainerColor = HotPink.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = if (viewModel.isSpinning) "КРУТИМ..." else "КРУТИТЬ 🔄",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Мини-оффер внизу
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2A0A2F)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.openPaywall() }
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "🔥 Акция заканчивается через ${viewModel.formatTime(viewModel.offerSecondsLeft)}",
                        color = Gold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "4000 монет всего за 499 ₽  •  СБП / МИР",
                        color = SoftPink,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "18+ • Оплата через СБП и карты МИР • Прототип",
                color = Color.Gray,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        // ========== PAYWALL ==========
        if (viewModel.showPaywall) {
            PaywallDialog(viewModel = viewModel)
        }
    }
}

@Composable
fun ReelBox(symbol: ReelSymbol) {
    Box(
        modifier = Modifier
            .size(92.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF1A1A1A))
            .border(2.dp, SoftPink.copy(alpha = 0.55f), RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = symbol.emoji, fontSize = 40.sp)
            Text(text = symbol.name, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
fun PaywallDialog(viewModel: SlotMachineViewModel) {
    Dialog(
        onDismissRequest = { viewModel.closePaywall() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(8.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF160A1C))
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "ПОПОЛНИ БАЛАНС",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = HotPink
                )
                Text(
                    text = "Оплата через СБП или карту МИР",
                    fontSize = 13.sp,
                    color = SoftPink,
                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                )

                // Таймер акции
                Text(
                    text = "⏰ Акция: ${viewModel.formatTime(viewModel.offerSecondsLeft)}",
                    color = Gold,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                COIN_PACKS.forEach { pack ->
                    PackCard(
                        pack = pack,
                        selected = viewModel.selectedPack?.id == pack.id,
                        onClick = { viewModel.selectPack(pack) }
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (viewModel.paymentSuccess) {
                    Text(
                        text = "✅ Успешно оплачено через СБП!",
                        color = Color(0xFF00FF88),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Button(
                        onClick = { viewModel.startPayment() },
                        enabled = viewModel.selectedPack != null && !viewModel.isPaying,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1DB954), // зелёный как у СБП
                            disabledContainerColor = Color.Gray
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(
                            text = if (viewModel.isPaying) "Обработка СБП..." else "Оплатить через СБП / МИР",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                TextButton(onClick = { viewModel.closePaywall() }) {
                    Text("Закрыть", color = Color.Gray)
                }

                Text(
                    text = "В реальной версии здесь YooKassa / CloudPayments\nс методами СБП и картами МИР",
                    color = Color.Gray.copy(alpha = 0.6f),
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }
}

@Composable
fun PackCard(pack: CoinPack, selected: Boolean, onClick: () -> Unit) {
    val borderColor = if (selected) Gold else if (pack.isBest) HotPink else Color.Gray.copy(alpha = 0.4f)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(2.dp, borderColor, RoundedCornerShape(14.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) Color(0xFF2A1535) else CardBg
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${pack.coins} монет",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (pack.badge != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = pack.badge,
                            color = if (pack.isBest) Gold else SoftPink,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .background(Color(0x33FF1493), RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                if (pack.oldPriceRub != null) {
                    Text(
                        text = "${pack.oldPriceRub} ₽",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        textDecoration = TextDecoration.LineThrough
                    )
                }
            }
            Text(
                text = "${pack.priceRub} ₽",
                color = Gold,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

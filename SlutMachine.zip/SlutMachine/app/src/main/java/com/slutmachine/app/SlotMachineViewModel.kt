package com.slutmachine.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ReelSymbol(
    val emoji: String,
    val name: String,
    val payout: Int
)

data class CoinPack(
    val id: String,
    val coins: Int,
    val priceRub: Int,
    val oldPriceRub: Int? = null,
    val badge: String? = null,
    val isBest: Boolean = false
)

val SYMBOLS = listOf(
    ReelSymbol("🍑", "Персик", 5),
    ReelSymbol("🍆", "Баклажан", 8),
    ReelSymbol("💋", "Поцелуй", 3),
    ReelSymbol("🔥", "Огонь", 4),
    ReelSymbol("💄", "Губы", 6),
    ReelSymbol("🍒", "Вишня", 2),
    ReelSymbol("💖", "Сердечки", 10),
    ReelSymbol("😘", "Подмигивание", 7),
    ReelSymbol("🌹", "Роза", 15)
)

val COIN_PACKS = listOf(
    CoinPack("pack_s", 500, 99, badge = null),
    CoinPack("pack_m", 1500, 249, oldPriceRub = 399, badge = "-38%"),
    CoinPack("pack_l", 4000, 499, oldPriceRub = 999, badge = "ХИТ", isBest = true),
    CoinPack("pack_xl", 12000, 999, oldPriceRub = 2499, badge = "ЛУЧШАЯ ЦЕНА")
)

class SlotMachineViewModel : ViewModel() {

    var coins by mutableStateOf(180)
        private set

    var bet by mutableStateOf(20)
        private set

    var isSpinning by mutableStateOf(false)
        private set

    var reels by mutableStateOf(listOf(SYMBOLS[0], SYMBOLS[1], SYMBOLS[2]))
        private set

    var lastWin by mutableStateOf(0)
        private set

    var message by mutableStateOf("Крути, детка... монетки ждут 😘")
        private set

    var showPaywall by mutableStateOf(false)
        private set

    var selectedPack by mutableStateOf<CoinPack?>(null)
        private set

    var isPaying by mutableStateOf(false)
        private set

    var paymentSuccess by mutableStateOf(false)
        private set

    var offerSecondsLeft by mutableStateOf(487)
        private set

    init {
        viewModelScope.launch {
            while (true) {
                delay(1000)
                if (offerSecondsLeft > 0) offerSecondsLeft--
            }
        }
    }

    fun increaseBet() {
        if (bet < 100 && !isSpinning) bet += 10
    }

    fun decreaseBet() {
        if (bet > 10 && !isSpinning) bet -= 10
    }

    fun spin() {
        if (isSpinning) return

        if (coins < bet) {
            message = "Монетки кончились, шлюшка 😈 Пополни баланс!"
            showPaywall = true
            return
        }

        viewModelScope.launch {
            isSpinning = true
            coins -= bet
            lastWin = 0
            message = "Крутим..."

            repeat(14) {
                reels = listOf(SYMBOLS.random(), SYMBOLS.random(), SYMBOLS.random())
                delay(70)
            }

            val result = listOf(SYMBOLS.random(), SYMBOLS.random(), SYMBOLS.random())
            reels = result

            val win = calculateWin(result)
            if (win > 0) {
                lastWin = win
                coins += win
                message = when {
                    win >= bet * 12 -> "ДЖЕКПОТ, ты грязная победительница! +$win 🔥"
                    win >= bet * 6 -> "Жирно! +$win монет 💋"
                    else -> "Неплохо, детка +$win"
                }
            } else {
                message = listOf(
                    "Почти... ещё разок 😘",
                    "Релы дразнят тебя...",
                    "Не сдавайся, шлюшка",
                    "Ещё чуть-чуть и сорвёшь"
                ).random()
            }

            if (coins < bet * 3) {
                delay(600)
                showPaywall = true
            }

            isSpinning = false
        }
    }

    private fun calculateWin(result: List<ReelSymbol>): Int {
        if (result[0].emoji == result[1].emoji && result[1].emoji == result[2].emoji) {
            return bet * result[0].payout
        }
        if (result[0].emoji == result[1].emoji) {
            return bet * (result[0].payout / 2).coerceAtLeast(1)
        }
        if (result[1].emoji == result[2].emoji) {
            return bet * (result[1].payout / 2).coerceAtLeast(1)
        }
        return 0
    }

    fun openPaywall() {
        showPaywall = true
        paymentSuccess = false
    }

    fun closePaywall() {
        if (!isPaying) {
            showPaywall = false
            selectedPack = null
            paymentSuccess = false
        }
    }

    fun selectPack(pack: CoinPack) {
        selectedPack = pack
    }

    fun startPayment() {
        val pack = selectedPack ?: return
        isPaying = true
        paymentSuccess = false

        viewModelScope.launch {
            delay(2200)
            // Здесь в проде: YooKassa / CloudPayments / Tinkoff SBP + Mir
            coins += pack.coins
            isPaying = false
            paymentSuccess = true
            message = "Оплачено через СБП! +${pack.coins} монет 💰"

            delay(1500)
            showPaywall = false
            selectedPack = null
            paymentSuccess = false
        }
    }

    fun formatTime(seconds: Int): String {
        val m = seconds / 60
        val s = seconds % 60
        return "%02d:%02d".format(m, s)
    }
}

package com.slutmachine.app.ui.theme

import androidx.compose.ui.graphics.Color

val HotPink = Color(0xFFFF1493)
val DeepPurple = Color(0xFF2D0A3A)
val DarkBg = Color(0xFF0D0D0D)
val Gold = Color(0xFFFFD700)
val SoftPink = Color(0xFFFF69B4)
val CardBg = Color(0xFF1A0A1F)
